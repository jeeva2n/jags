<?php
/*
 * Deployment overrides for JAGS Technologies.
 *
 * On shared hosting (cPanel etc.) environment variables are often not
 * available to PHP, so config.php also reads this file when present.
 *
 * HOW TO USE:
 *   1. Copy this file to  includes/config.local.php
 *   2. Fill in the values your hosting panel gives you
 *      (MySQL Databases section in cPanel).
 *   3. Do NOT commit config.local.php to the repo.
 *
 * On many hosts the database/user names get a cPanel prefix, e.g.:
 *   DB_NAME => 'cpaneluser_jags_technologies'
 *   DB_USER => 'cpaneluser_jags'
 *
 * DB_DIAGNOSTIC (optional, defaults to false): set to true ONLY while
 * debugging so db-check.php can show connector details. Remove it after.
 */
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'jags_technologies',
    'DB_USER' => 'root',
    'DB_PASS' => '',
    // 'APP_BASE_URL' => 'https://alphasonix.com/jags/demo',
    // 'DB_DIAGNOSTIC' => true,
];