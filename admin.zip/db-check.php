<?php
/*
 * JAGS Technologies — database connection diagnostic.
 *
 * Purpose: reveal the REAL reason the site shows "Database connection
 * failed" on your hosting account.
 *
 * Security: this script is disabled unless includes/config.local.php
 * contains 'DB_DIAGNOSTIC' => true. To run it:
 *
 *   1. Upload this file to the web root (next to index.php).
 *   2. Copy includes/config.local.example.php -> includes/config.local.php
 *      and uncomment 'DB_DIAGNOSTIC' => true.
 *   3. Visit  https://alphasonix.com/jags/demo/db-check.php
 *   4. Read the report, then REMOVE config.local.php and db-check.php
 *      from the server.
 */
require_once __DIR__ . '/includes/config.php';

if (!defined('DB_DIAGNOSTIC') || !DB_DIAGNOSTIC) {
    http_response_code(404);
    exit('Not found');
}

header('Content-Type: text/plain; charset=utf-8');

echo "=== JAGS Technologies DB diagnostic ===\n\n";
echo 'PHP:        ' . PHP_VERSION . "\n";
echo 'APP_ENV:    ' . APP_ENV . "\n";
echo 'BASE_URL:   ' . BASE_URL . "\n";
echo 'DB_HOST:    ' . DB_HOST . "\n";
echo 'DB_NAME:    ' . DB_NAME . "\n";
echo 'DB_USER:    ' . DB_USER . "\n";
echo 'DB_PASS:    ' . (DB_PASS === '' ? '(empty)' : '(set)') . "\n\n";

echo 'Testing connection...' . "\n";
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $pdo->query('SELECT 1');
    echo "CONNECTION OK - the database is reachable.\n\n";

    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    echo 'Tables in database (' . count($tables) . "):\n  " . (count($tables) ? implode(', ', $tables) : '(none)') . "\n\n";

    $ok = $pdo->query("SELECT setting_key FROM site_settings WHERE setting_key IN ('admin_username','admin_password_hash') ORDER BY setting_key")->fetchAll(PDO::FETCH_COLUMN);
    echo 'Admin credentials installed: ' . (count($ok) ? implode(', ', $ok) : 'MISSING - import database/update.sql') . "\n";

    $img = $pdo->query("SELECT COUNT(*) FROM timeline_stages WHERE image IS NOT NULL AND image <> ''")->fetchColumn();
    echo 'Timeline stages with images: ' . $img . " (expected 10)\n";
} catch (PDOException $e) {
    echo "CONNECTION FAILED:\n" . $e->getMessage() . "\n\n";
    echo "Fixes to check:\n";
    echo "  - Compare DB_HOST / DB_NAME / DB_USER / DB_PASS with the values in your\n";
    echo "    hosting panel (cPanel -> MySQL Databases / phpMyAdmin -> right panel info).\n";
    echo "  - On cPanel the database name is usually prefixed, e.g. user_jags_technologies.\n";
    echo "  - Make sure the user has been granted ALL PRIVILEGES on that database.\n";
    echo "  - Set the correct values in includes/config.local.php.\n\n";
}

echo "\nDone.\n";