<?php
/*
 * TEMPORARY diagnostic for the live site. DELETE THIS FILE FROM THE
 * SERVER AS SOON AS THE PROBLEM IS FIXED (it contains credentials).
 *
 * Upload to /jags/demo/diag.php and visit:
 *   https://alphasonix.com/jags/demo/diag.php
 */
header('Content-Type: text/plain; charset=utf-8');

$host = 'localhost';
$db   = 'dakstbvk_jags_technologies';
$user = 'dakstbvk_jags_technologies';
$pass = 'Alphasonix@2026.';

echo "=== JAGS diagnostic (self-contained) ===\n\n";
echo "Host: $host\nDatabase: $db\nUser: $user\n\n";
echo "Testing connection ...\n";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    $pdo->query('SELECT 1');
    echo "CONNECTION OK\n\n";

    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    echo 'Tables (' . count($tables) . '): ' . (count($tables) ? implode(', ', $tables) : '(none)') . "\n\n";

    $admin = (int)$pdo->query("SELECT COUNT(*) FROM site_settings WHERE setting_key IN ('admin_username','admin_password_hash')")->fetchColumn();
    echo "Admin credential rows: $admin  (needs 2)\n";

    $imgs = (int)$pdo->query("SELECT COUNT(*) FROM timeline_stages WHERE image IS NOT NULL AND image <> ''")->fetchColumn();
    echo "Timeline stages with images: $imgs  (needs 10)\n";
} catch (PDOException $e) {
    echo "CONNECTION FAILED:\n" . $e->getMessage() . "\n";
}

echo "\nDone.\n";