<?php
/*
 * JAGS Technologies — admin password reset tool (CLI only)
 *
 * Use this ONLY if you do not know the admin password on the server
 * (e.g. the local copy was seeded with a random bootstrap password).
 * Run it over SSH / terminal after uploading the project:
 *
 *   php database/set-admin-password.php admin YourNewPassword123
 *
 * It writes the credentials straight into site_settings. DELETE this
 * file from the server once you have logged in and changed the
 * password from Admin -> Settings.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This tool can only be run from the command line.\n");
}

require_once __DIR__ . '/../includes/config.php';

$username = $argv[1] ?? '';
$password = $argv[2] ?? '';

if ($username === '' || $password === '') {
    fwrite(STDERR, "Usage: php database/set-admin-password.php <username> <password>\n");
    exit(1);
}
if (strlen($password) < 8) {
    fwrite(STDERR, "Password must be at least 8 characters.\n");
    exit(1);
}

$db = getDB();
$stmt = $db->prepare(
    "INSERT INTO site_settings (setting_key, setting_value) VALUES
     ('admin_username', ?), ('admin_password_hash', ?)
     ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
);
$stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);

echo "Admin credentials updated: " . $username . "\n";
echo "Log in at " . BASE_URL . "/admin/login.php and change this password from Settings.\n";
echo "Remember to delete this file from the server.\n";