-- ============================================================
-- JAGS Technologies — production live-fix patch
-- ------------------------------------------------------------
-- Fixes on the live site (https://alphasonix.com/jags/demo):
--   1) Content images were missing because the production
--      database (imported from database/setup.sql) had no
--      image paths. This patch attaches the uploaded images
--      that already exist on the server.
--   2) Admin login failed because site_settings had no
--      admin_username / admin_password_hash rows, and
--      production refuses to auto-seed them.
--
-- HOW TO APPLY:
--   Open phpMyAdmin on the production host -> select the
--   jags_technologies database -> Import / SQL tab -> paste
--   this file. It is idempotent and never drops data.
--
-- NOTE: admin credentials are the same as your LOCAL admin
-- panel. Change the password from Admin -> Settings after
-- your first login.
-- ============================================================

-- 1) Admin credentials (same username/password as local site)
INSERT INTO site_settings (setting_key, setting_value) VALUES
('admin_username', 'admin'),
('admin_password_hash', '$2y$10$W5I4dYJgwPdnmSiiIjji9.ZwbFXTVVKTA/aw4EFPl0WeTv832qJHa')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- 2) Timeline (Workflow) stage images — these files are on the server
UPDATE timeline_stages SET image = 'assets/uploads/20260911-0393a22c8667.webp' WHERE step_number = 1;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-4aa8280fc74e.webp'  WHERE step_number = 2;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-80205398c2a2.webp' WHERE step_number = 3;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-3f85df5b7034.webp'  WHERE step_number = 4;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-14b131db69f4.webp' WHERE step_number = 5;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-5c2ee33a850b.webp'  WHERE step_number = 6;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-f2ac6c9b6940.webp' WHERE step_number = 7;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-b6e2bdf73665.webp' WHERE step_number = 8;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-08ddb0de64bd.webp' WHERE step_number = 9;
UPDATE timeline_stages SET image = 'assets/uploads/20260911-2501a0be898b.webp' WHERE step_number = 10;

-- 3) NDT category image
UPDATE categories SET image = 'assets/uploads/20260911-a305319af2da.png' WHERE slug = 'eddy-current';

-- 4) Demo product that exists locally but was not shipped by setup.sql
INSERT INTO products (name, slug, category_id, technology, image, is_active, sort_order)
SELECT 'calibration blocks',
       'used-testing-ut',
       (SELECT id FROM categories WHERE slug = 'calibration-blocks' LIMIT 1),
       'NDT teCH',
       'assets/uploads/20260910-e32644e2581d.webp',
       1,
       0
WHERE NOT EXISTS (SELECT 1 FROM products WHERE slug = 'used-testing-ut');