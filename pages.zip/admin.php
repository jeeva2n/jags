<?php
require_once __DIR__ . '/includes/config.php';
header('Location: ' . BASE_URL . '/admin/index.php');
exit;